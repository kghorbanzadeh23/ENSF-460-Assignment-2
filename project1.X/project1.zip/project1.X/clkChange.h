/*
 * File:  clkchange.h
 * Author: Spiro, Kamand, Hutton
 *
 * Created on: 2024/09/23
 */
#ifndef CHANGECLK_H
#define CHANGECLK_H

#include <xc.h>

// Function declarations
void newClk(unsigned int clkval);

#endif // CHANGECLK_H